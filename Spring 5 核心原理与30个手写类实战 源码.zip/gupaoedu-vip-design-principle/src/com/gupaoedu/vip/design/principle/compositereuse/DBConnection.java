package com.gupaoedu.vip.design.principle.compositereuse;

/**
 * Created by Tom
 */
public abstract class DBConnection {
//    public String getConnection(){
//        return "MySQL数据库连接";
//    }
    public abstract String getConnection();
}
