package com.gupaoedu.vip.design.principle.dependencyinversion;

/**
 * Created by Tom
 */
public interface ICourse {
    void study();
}
