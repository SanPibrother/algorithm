package com.gupaoedu.vip.design.principle.interfacegregation.gregation;

/**
 * Created by Tom
 */
public class Bird implements IFlyAnimal,IEatAnimal {

    @Override
    public void eat() {

    }

    @Override
    public void fly() {

    }

}
