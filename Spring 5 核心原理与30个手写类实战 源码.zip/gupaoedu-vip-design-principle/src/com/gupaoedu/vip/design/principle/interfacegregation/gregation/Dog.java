package com.gupaoedu.vip.design.principle.interfacegregation.gregation;

/**
 * Created by Tom
 */
public class Dog implements ISwimAnimal,IEatAnimal {

    @Override
    public void eat() {

    }

    @Override
    public void swim() {

    }

}
