package com.gupaoedu.vip.design.principle.interfacegregation.gregation;

/**
 * Created by Tom
 */
public interface IEatAnimal {

    void eat();

}
