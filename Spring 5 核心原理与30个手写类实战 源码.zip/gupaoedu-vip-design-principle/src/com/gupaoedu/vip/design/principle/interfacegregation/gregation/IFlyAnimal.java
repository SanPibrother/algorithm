package com.gupaoedu.vip.design.principle.interfacegregation.gregation;

/**
 * Created by Tom
 */
public interface IFlyAnimal {

    void fly();

}
