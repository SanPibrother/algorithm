package com.gupaoedu.vip.design.principle.interfacegregation.simple;

/**
 * Created by Tom
 */
public class Bird implements IAnimal {

    @Override
    public void eat() {

    }

    @Override
    public void fly() {

    }

    @Override
    public void swim() {

    }

}
