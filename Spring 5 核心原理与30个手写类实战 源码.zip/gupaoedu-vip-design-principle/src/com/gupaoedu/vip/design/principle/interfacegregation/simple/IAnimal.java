package com.gupaoedu.vip.design.principle.interfacegregation.simple;

/**
 * Created by Tom
 */
public interface IAnimal {

    void eat();

    void fly();

    void swim();

}
