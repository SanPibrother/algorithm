package com.gupaoedu.vip.design.principle.lawofdemeter;

/**
 * Created by Tom
 */
public class Course {
}
