package com.gupaoedu.vip.design.principle.liskovsubstitution;

/**
 * 四边形
 * Created by Tom
 */
public interface Quadrangle {
    long getWidth();
    long getHeight();
}
