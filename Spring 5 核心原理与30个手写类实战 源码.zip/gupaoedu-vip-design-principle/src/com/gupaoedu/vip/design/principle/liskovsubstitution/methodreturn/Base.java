package com.gupaoedu.vip.design.principle.liskovsubstitution.methodreturn;

import java.util.Map;

/**
 * Created by Tom
 */
public abstract class Base {
    public abstract Map method();

}
