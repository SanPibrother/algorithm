package com.gupaoedu.vip.design.principle.openclose;

/**
 * Created by Tom
 */
public interface ICourse {
    Integer getId();
    String getName();
    Double getPrice();
}
