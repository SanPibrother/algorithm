package com.gupaoedu.vip.design.principle.simpleresponsibility.interfaced;

/**
 * Created by Tom
 */
public interface ICourseInfo {
    String getCourseName();
    byte[] getCourseVideo();
}
