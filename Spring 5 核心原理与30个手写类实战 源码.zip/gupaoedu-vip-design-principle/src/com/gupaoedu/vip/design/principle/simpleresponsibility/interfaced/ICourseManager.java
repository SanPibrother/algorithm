package com.gupaoedu.vip.design.principle.simpleresponsibility.interfaced;

/**
 * Created by Tom
 */
public interface ICourseManager {
    void studyCourse();
    void refundCourse();
}
