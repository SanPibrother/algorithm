package com.gupaoedu.vip.design.principle.simpleresponsibility.simple;

/**
 * Created by Tom.
 */
public class LiveCourse {
    public void study(String courseName){
        System.out.println(courseName + "可以反复回看");
    }
}
