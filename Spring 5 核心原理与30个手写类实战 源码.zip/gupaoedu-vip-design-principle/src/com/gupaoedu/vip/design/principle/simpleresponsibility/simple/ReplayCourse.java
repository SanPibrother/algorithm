package com.gupaoedu.vip.design.principle.simpleresponsibility.simple;

/**
 * Created by Tom.
 */
public class ReplayCourse {
    public void study(String courseName){
        System.out.println(courseName + "不能快进");
    }
}
