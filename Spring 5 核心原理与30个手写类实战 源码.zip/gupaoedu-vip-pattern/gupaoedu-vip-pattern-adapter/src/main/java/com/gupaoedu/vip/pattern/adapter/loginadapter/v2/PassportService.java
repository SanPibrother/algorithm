package com.gupaoedu.vip.pattern.adapter.loginadapter.v2;

import com.gupaoedu.vip.pattern.adapter.loginadapter.ResultMsg;

/**
 * Created by Tom.
 */
public class PassportService {


    /**
     * 登录
     * @param username
     * @param passport
     * @return
     */
    public ResultMsg regist(String username,String passport){
        return null;
    }


    /**
     * 注册
     * @param username
     * @param passport
     * @return
     */
    public ResultMsg login(String username,String passport){
        return null;
    }


}
