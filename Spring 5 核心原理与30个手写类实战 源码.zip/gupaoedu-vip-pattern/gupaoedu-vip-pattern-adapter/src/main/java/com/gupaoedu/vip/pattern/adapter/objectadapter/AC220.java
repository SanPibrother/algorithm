package com.gupaoedu.vip.pattern.adapter.objectadapter;

/**
 * Created by Tom
 */
public class AC220 {
    public int outputAC220V(){
        int output = 220;
        System.out.println("输出交流电"+output+"V");
        return output;
    }
}
