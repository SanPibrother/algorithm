package com.gupaoedu.vip.pattern.adapter.objectadapter;

/**
 * Created by Tom
 */
public interface DC5 {
    int outputDC5V();
}
