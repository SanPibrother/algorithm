package com.gupaoedu.vip.pattern.delegate.mvc.controllers;

/**
 * Created by Tom.
 */
public class OrderController {

    public void getOrderById(String mid){

    }

}
