package com.gupaoedu.vip.pattern.delegate.simple;

/**
 * Created by Tom.
 */
public interface IEmployee {

    public void doing(String command);

}
