package com.gupaoedu.vip.pattern.factory;

/**
 * Created by Tom.
 */
public interface ICourse {
    /**
     * 录制视频
     * @return
     */
    void record();
}
