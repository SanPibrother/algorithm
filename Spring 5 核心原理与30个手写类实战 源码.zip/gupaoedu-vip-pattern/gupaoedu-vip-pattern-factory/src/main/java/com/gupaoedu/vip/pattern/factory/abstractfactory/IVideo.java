package com.gupaoedu.vip.pattern.factory.abstractfactory;

/**
 * 录播视频
 * Created by Tom.
 */
public interface IVideo {
    void record();
}
