package com.gupaoedu.vip.pattern.factory.abstractfactory;


/**
 * Created by Tom on.
 */
public class JavaVideo implements IVideo {
    public void record() {
        System.out.println("录制Java视频");
    }
}
