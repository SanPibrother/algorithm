package com.gupaoedu.vip.pattern.prototype.deep;

import java.util.Date;

/**
 * Created by Tom.
 */
public class Monkey {
    public int height;
    public int weight;
    public Date birthday;

}
