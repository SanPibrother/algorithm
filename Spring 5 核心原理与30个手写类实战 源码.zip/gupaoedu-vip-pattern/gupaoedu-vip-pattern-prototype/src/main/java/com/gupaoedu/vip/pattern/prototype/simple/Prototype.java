package com.gupaoedu.vip.pattern.prototype.simple;

/**
 * Created by Tom.
 */
public interface Prototype{
    Prototype clone();
}
