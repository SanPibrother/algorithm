package com.gupaoedu.vip.pattern.proxy.dbroute;

/**
 * Created by Tom.
 */
public interface IOrderService {
    int createOrder(Order order);
}
