package com.gupaoedu.vip.pattern.proxy.dynamicproxy.cglibproxy;

/**
 * Created by Tom on 2019/3/11.
 */
public class Customer {

    public void findLove(){
        System.out.println("儿子要求：肤白貌美大长腿");
    }
}
