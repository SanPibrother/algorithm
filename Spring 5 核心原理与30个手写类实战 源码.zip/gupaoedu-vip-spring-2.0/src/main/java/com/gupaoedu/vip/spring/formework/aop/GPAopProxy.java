package com.gupaoedu.vip.spring.formework.aop;

/**
 * Created by Tom.
 */
public interface GPAopProxy {


    Object getProxy();


    Object getProxy(ClassLoader classLoader);
}
