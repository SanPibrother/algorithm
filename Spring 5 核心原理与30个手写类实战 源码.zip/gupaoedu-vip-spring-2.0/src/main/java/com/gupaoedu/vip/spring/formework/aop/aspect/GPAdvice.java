package com.gupaoedu.vip.spring.formework.aop.aspect;

/**
 * Created by Tom on 2019/4/15.
 */
public interface GPAdvice {
}
